gcc_pent.h
stat_pent.h
uname_pent.h
