int getopt_long(int argc, char *argv[], const char *optstring,
				  const struct option *longopts, int *longindex);
int getopt_long_only(int argc, char *argv[], const char *optstring,
				  const struct option *longopts, int *longindex);

