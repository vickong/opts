
int kill(pid_t pid, int sig);
