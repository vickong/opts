int _IO_putc(char c) PREFER int putchar(1);
int __xstat (int __ver,
			 const char *__filename,
			 struct stat *__stat_buf) PREFER int stat(2,3);

