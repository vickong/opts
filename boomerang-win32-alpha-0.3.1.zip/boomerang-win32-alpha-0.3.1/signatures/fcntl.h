int open(const char *path, int flags, ...);
