This is alpha release 0.3.1 of the Boomerang decompiler.

	http://boomerang.sourceforge.net/

Source code for the latest release is available as usual from the Boomerang CVS.

Most of this package can be distributed under the terms outlined in the LICENSE.TERMS file.
However, boomerang-gui.exe is linked to the QtCore4.dll and QtGui4.dll which must be
distributed under the terms outlined in the LICENSE.GPL file.  Please ensure you understand
these terms before redistributing this software.

Happy decompiling.

Mike and Trent
07/Sep/2006
